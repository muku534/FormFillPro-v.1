const FakeDataGenerator = {
  firstNames: [
    'James', 'Mary', 'Robert', 'Patricia', 'John', 'Jennifer', 'Michael', 'Linda',
    'David', 'Elizabeth', 'William', 'Barbara', 'Richard', 'Susan', 'Joseph', 'Jessica',
    'Thomas', 'Sarah', 'Christopher', 'Karen', 'Charles', 'Lisa', 'Daniel', 'Nancy',
    'Matthew', 'Betty', 'Anthony', 'Margaret', 'Mark', 'Sandra', 'Donald', 'Ashley',
    'Steven', 'Kimberly', 'Paul', 'Emily', 'Andrew', 'Donna', 'Joshua', 'Michelle',
    'Kenneth', 'Dorothy', 'Kevin', 'Carol', 'Brian', 'Amanda', 'George', 'Melissa'
  ],

  lastNames: [
    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis',
    'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson',
    'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin', 'Lee', 'Perez', 'Thompson',
    'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson', 'Walker',
    'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen', 'Hill', 'Flores',
    'Green', 'Adams', 'Nelson', 'Baker', 'Hall', 'Rivera', 'Campbell', 'Mitchell'
  ],

  streetNames: [
    'Main', 'Oak', 'Cedar', 'Maple', 'Pine', 'Elm', 'Washington', 'Lake', 'Hill',
    'Park', 'River', 'Forest', 'Spring', 'Valley', 'Sunset', 'Highland', 'Meadow'
  ],

  streetTypes: ['St', 'Ave', 'Blvd', 'Dr', 'Ln', 'Rd', 'Way', 'Ct'],

  cities: [
    'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia',
    'San Antonio', 'San Diego', 'Dallas', 'San Jose', 'Austin', 'Jacksonville',
    'Fort Worth', 'Columbus', 'Charlotte', 'San Francisco', 'Indianapolis', 'Seattle'
  ],

  states: [
    { name: 'California', abbr: 'CA' }, { name: 'Texas', abbr: 'TX' },
    { name: 'Florida', abbr: 'FL' }, { name: 'New York', abbr: 'NY' },
    { name: 'Pennsylvania', abbr: 'PA' }, { name: 'Illinois', abbr: 'IL' },
    { name: 'Ohio', abbr: 'OH' }, { name: 'Georgia', abbr: 'GA' },
    { name: 'North Carolina', abbr: 'NC' }, { name: 'Michigan', abbr: 'MI' }
  ],

  companies: [
    'Acme Corp', 'GlobalTech Solutions', 'Innovate Inc', 'TechVentures', 'DataFlow Systems',
    'CloudScale', 'NextGen Software', 'Digital Dynamics', 'CyberCore', 'FutureTech'
  ],

  domains: ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'mail.com'],

  jobTitles: [
    'Software Engineer', 'Product Manager', 'Data Analyst', 'UX Designer', 'DevOps Engineer',
    'QA Engineer', 'Frontend Developer', 'Backend Developer', 'Full Stack Developer',
    'Project Manager', 'Business Analyst', 'Technical Lead', 'System Administrator'
  ],

  random(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  },

  randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  firstName() {
    return this.random(this.firstNames);
  },

  lastName() {
    return this.random(this.lastNames);
  },

  fullName() {
    return `${this.firstName()} ${this.lastName()}`;
  },

  email(firstName, lastName) {
    const fn = (firstName || this.firstName()).toLowerCase();
    const ln = (lastName || this.lastName()).toLowerCase();
    const domain = this.random(this.domains);
    const patterns = [`${fn}.${ln}`, `${fn}${ln}`, `${fn}_${ln}`, `${fn}${this.randomInt(1, 99)}`];
    return `${this.random(patterns)}@${domain}`;
  },

  phone() {
    return `(${this.randomInt(200, 999)}) ${this.randomInt(200, 999)}-${this.randomInt(1000, 9999)}`;
  },

  streetAddress() {
    return `${this.randomInt(100, 9999)} ${this.random(this.streetNames)} ${this.random(this.streetTypes)}`;
  },

  city() {
    return this.random(this.cities);
  },

  state(abbreviated = false) {
    const state = this.random(this.states);
    return abbreviated ? state.abbr : state.name;
  },

  zipCode() {
    return String(this.randomInt(10000, 99999));
  },

  company() {
    return this.random(this.companies);
  },

  jobTitle() {
    return this.random(this.jobTitles);
  },

  username(firstName, lastName) {
    const fn = (firstName || this.firstName()).toLowerCase();
    const ln = (lastName || this.lastName()).toLowerCase();
    const patterns = [`${fn}${ln}`, `${fn}_${ln}`, `${fn}${this.randomInt(1, 999)}`];
    return this.random(patterns);
  },

  password(length = 12) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    password += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[this.randomInt(0, 25)];
    password += 'abcdefghijklmnopqrstuvwxyz'[this.randomInt(0, 25)];
    password += '0123456789'[this.randomInt(0, 9)];
    password += '!@#$%^&*'[this.randomInt(0, 7)];
    for (let i = 4; i < length; i++) {
      password += chars[this.randomInt(0, chars.length - 1)];
    }
    return password.split('').sort(() => Math.random() - 0.5).join('');
  },

  date(startYear = 1950, endYear = 2005) {
    const year = this.randomInt(startYear, endYear);
    const month = String(this.randomInt(1, 12)).padStart(2, '0');
    const day = String(this.randomInt(1, 28)).padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  birthDate() {
    return this.date(1960, 2000);
  },

  creditCard() {
    let num = '4';
    for (let i = 0; i < 15; i++) {
      num += this.randomInt(0, 9);
    }
    return num;
  },

  cvv() {
    return String(this.randomInt(100, 999));
  },

  expirationDate() {
    const month = String(this.randomInt(1, 12)).padStart(2, '0');
    const year = this.randomInt(25, 30);
    return `${month}/${year}`;
  },

  ssn() {
    return `${this.randomInt(100, 999)}-${this.randomInt(10, 99)}-${this.randomInt(1000, 9999)}`;
  },

  website() {
    const tlds = ['.com', '.net', '.org', '.io'];
    const name = this.random(this.companies).toLowerCase().replace(/\s+/g, '');
    return `https://www.${name}${this.random(tlds)}`;
  },

  paragraph() {
    const sentences = [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.',
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.'
    ];
    return sentences.slice(0, this.randomInt(2, 4)).join(' ');
  },

  sentence() {
    const subjects = ['The developer', 'A user', 'The system', 'An engineer'];
    const verbs = ['creates', 'updates', 'manages', 'processes'];
    const objects = ['data efficiently', 'forms automatically', 'tests quickly'];
    return `${this.random(subjects)} ${this.random(verbs)} ${this.random(objects)}.`;
  },

  subject() {
    const subjects = [
      'General Inquiry',
      'Product Question',
      'Support Request',
      'Feedback',
      'Partnership Opportunity',
      'Technical Issue',
      'Feature Request',
      'Account Question',
      'Billing Inquiry',
      'Service Information'
    ];
    return this.random(subjects);
  },

  age(min = 18, max = 80) {
    return this.randomInt(min, max);
  },

  gender() {
    return this.random(['Male', 'Female', 'Other', 'Prefer not to say']);
  },

  country() {
    return this.random(['United States', 'Canada', 'United Kingdom', 'Australia', 'Germany', 'France']);
  },

  generateProfile() {
    const firstName = this.firstName();
    const lastName = this.lastName();
    return {
      firstName,
      lastName,
      fullName: `${firstName} ${lastName}`,
      email: this.email(firstName, lastName),
      phone: this.phone(),
      username: this.username(firstName, lastName),
      password: this.password(),
      birthDate: this.birthDate(),
      age: this.age(),
      gender: this.gender(),
      address: {
        street: this.streetAddress(),
        city: this.city(),
        state: this.state(),
        stateAbbr: this.state(true),
        zipCode: this.zipCode(),
        country: this.country()
      },
      company: this.company(),
      jobTitle: this.jobTitle(),
      website: this.website()
    };
  }
};

const FieldDetector = {
  patterns: {
    email: { attributes: ['email', 'e-mail', 'mail'], validFor: ['input'], autocomplete: ['email'] },
    password: { attributes: ['password', 'passwd', 'pwd'], validFor: ['input'], autocomplete: ['current-password', 'new-password'] },
    confirmPassword: { attributes: ['confirm-password', 'confirmpassword', 'verify-password', 'retype-password', 'repeat-password'], validFor: ['input'], autocomplete: ['new-password'] },
    firstName: { attributes: ['firstname', 'first-name', 'first_name', 'fname', 'given-name', 'givenname'], validFor: ['input'], autocomplete: ['given-name'] },
    lastName: { attributes: ['lastname', 'last-name', 'last_name', 'lname', 'surname', 'family-name', 'familyname'], validFor: ['input'], autocomplete: ['family-name'] },
    fullName: { attributes: ['fullname', 'full-name', 'full_name', 'your-name', 'yourname'], validFor: ['input'], autocomplete: ['name'] },
    phone: { attributes: ['phone', 'telephone', 'mobile', 'cell', 'phonenumber'], validFor: ['input'], autocomplete: ['tel', 'tel-national'] },
    address: { attributes: ['address', 'street', 'address1', 'streetaddress', 'address-line'], validFor: ['input', 'textarea'], autocomplete: ['street-address', 'address-line1'] },
    city: { attributes: ['city', 'town', 'locality'], validFor: ['input'], autocomplete: ['address-level2'] },
    state: { attributes: ['state', 'province', 'region'], validFor: ['input', 'select'], autocomplete: ['address-level1'] },
    zipCode: { attributes: ['zip', 'zipcode', 'postal', 'postalcode', 'postcode'], validFor: ['input'], autocomplete: ['postal-code'] },
    country: { attributes: ['country', 'nation'], validFor: ['input', 'select'], autocomplete: ['country', 'country-name'] },
    username: { attributes: ['username', 'user-name', 'userid', 'login-id', 'loginid'], validFor: ['input'], autocomplete: ['username'] },
    company: { attributes: ['company', 'organization', 'employer', 'business', 'companyname'], validFor: ['input'], autocomplete: ['organization'] },
    jobTitle: { attributes: ['jobtitle', 'job-title', 'job_title', 'position', 'occupation'], validFor: ['input'], autocomplete: ['organization-title'] },
    website: { attributes: ['website', 'url', 'homepage', 'site-url', 'webpage'], validFor: ['input'], autocomplete: ['url'] },
    birthDate: { attributes: ['birthdate', 'birth-date', 'dob', 'dateofbirth', 'birthday'], validFor: ['input'], autocomplete: ['bday'] },
    age: { attributes: ['age', 'years-old'], validFor: ['input'], autocomplete: [] },
    gender: { attributes: ['gender', 'sex'], validFor: ['select', 'input'], autocomplete: ['sex'] },
    creditCard: { attributes: ['creditcard', 'cardnumber', 'card-number', 'ccnum', 'cc-number'], validFor: ['input'], autocomplete: ['cc-number'] },
    cvv: { attributes: ['cvv', 'cvc', 'securitycode', 'security-code', 'csc'], validFor: ['input'], autocomplete: ['cc-csc'] },
    expirationDate: { attributes: ['expiration', 'expiry', 'exp-date', 'expdate'], validFor: ['input'], autocomplete: ['cc-exp'] },
    expirationMonth: { attributes: ['exp-month', 'expmonth', 'expirationmonth'], validFor: ['input', 'select'], autocomplete: ['cc-exp-month'] },
    expirationYear: { attributes: ['exp-year', 'expyear', 'expirationyear'], validFor: ['input', 'select'], autocomplete: ['cc-exp-year'] },
    ssn: { attributes: ['ssn', 'social-security', 'socialsecurity'], validFor: ['input'], autocomplete: [] },
    subject: { attributes: ['subject', 'topic', 'title', 'inquiry', 'regarding'], validFor: ['input'], autocomplete: [] },
    message: { attributes: ['message', 'comment', 'comments', 'description', 'body', 'content', 'inquiry', 'feedback', 'question', 'details'], validFor: ['textarea', 'input'], autocomplete: [] }
  },

  getFieldAttributes(element) {
    const dataAttrs = [];
    for (const attr of element.attributes) {
      if (attr.name.startsWith('data-')) {
        dataAttrs.push(attr.value.toLowerCase());
      }
    }

    const attrs = {
      id: (element.id || '').toLowerCase(),
      name: (element.name || '').toLowerCase(),
      type: (element.type || '').toLowerCase(),
      placeholder: (element.placeholder || '').toLowerCase(),
      autocomplete: (element.autocomplete || '').toLowerCase(),
      className: (typeof element.className === 'string' ? element.className : '').toLowerCase(),
      ariaLabel: (element.getAttribute('aria-label') || '').toLowerCase(),
      ariaDescribedby: (element.getAttribute('aria-describedby') || '').toLowerCase(),
      dataAttrs: dataAttrs.join(' '),
      label: ''
    };

    const labelElement = this.findAssociatedLabel(element);
    if (labelElement) {
      attrs.label = labelElement.textContent.toLowerCase().trim();
    }

    if (element.getAttribute('aria-describedby')) {
      const describedById = element.getAttribute('aria-describedby');
      const describedByEl = document.getElementById(describedById);
      if (describedByEl) {
        attrs.label += ' ' + describedByEl.textContent.toLowerCase().trim();
      }
    }

    return attrs;
  },

  findAssociatedLabel(element) {
    if (element.id) {
      const label = document.querySelector(`label[for="${element.id}"]`);
      if (label) return label;
    }

    const parentLabel = element.closest('label');
    if (parentLabel) return parentLabel;

    const wrapper = element.closest('div, span, fieldset, section');
    if (wrapper) {
      const label = wrapper.querySelector('label');
      if (label) return label;

      const spans = wrapper.querySelectorAll('span, p, div');
      for (const span of spans) {
        const text = span.textContent?.trim();
        if (text && text.length < 100 && span !== element && !span.contains(element)) {
          return span;
        }
      }
    }

    let prev = element.previousElementSibling;
    while (prev) {
      if (prev.tagName === 'LABEL' || (prev.textContent?.trim().length < 100)) {
        return prev;
      }
      prev = prev.previousElementSibling;
    }

    return null;
  },

  detectFieldType(element) {
    const attrs = this.getFieldAttributes(element);
    const tagName = element.tagName.toLowerCase();
    const elementType = tagName === 'input' ? 'input' : tagName;

    if (attrs.autocomplete) {
      for (const [fieldType, pattern] of Object.entries(this.patterns)) {
        if (pattern.autocomplete.includes(attrs.autocomplete) && this.isValidForElement(pattern, elementType)) {
          return fieldType;
        }
      }
    }

    if (attrs.type === 'email') return 'email';
    if (attrs.type === 'password') {
      const searchString = `${attrs.id} ${attrs.name} ${attrs.placeholder} ${attrs.label}`;
      if (this.matchesWordBoundary(searchString, this.patterns.confirmPassword.attributes)) {
        return 'confirmPassword';
      }
      return 'password';
    }
    if (attrs.type === 'tel') return 'phone';
    if (attrs.type === 'url') return 'website';

    const primaryFields = `${attrs.id} ${attrs.name}`.toLowerCase();
    const secondaryFields = `${attrs.placeholder} ${attrs.label}`.toLowerCase();

    let bestMatch = null;
    let bestScore = 0;

    for (const [fieldType, pattern] of Object.entries(this.patterns)) {
      if (!this.isValidForElement(pattern, elementType)) continue;

      let score = 0;

      for (const attr of pattern.attributes) {
        if (this.matchesWordBoundary(primaryFields, [attr])) {
          score += 10;
        }
        if (this.matchesWordBoundary(secondaryFields, [attr])) {
          score += 5;
        }
      }

      if (score > bestScore) {
        bestScore = score;
        bestMatch = fieldType;
      }
    }

    if (bestMatch && bestScore >= 5) {
      return bestMatch;
    }

    if (tagName === 'textarea') {
      return 'message';
    }

    const labelLower = attrs.label.toLowerCase();
    if (labelLower.includes('name') && !labelLower.includes('user')) {
      if (labelLower.includes('full') || labelLower.includes('your')) {
        return 'fullName';
      }
      if (labelLower.includes('first')) return 'firstName';
      if (labelLower.includes('last')) return 'lastName';
      return 'fullName';
    }

    return 'text';
  },

  isValidForElement(pattern, elementType) {
    if (!pattern.validFor) return true;
    return pattern.validFor.includes(elementType);
  },

  matchesWordBoundary(searchString, patterns) {
    const words = searchString.toLowerCase().split(/[\s_\-.,]+/);
    return patterns.some(pattern => {
      const patternLower = pattern.toLowerCase();
      if (words.includes(patternLower)) return true;
      if (searchString.toLowerCase().includes(patternLower)) {
        const regex = new RegExp(`(^|[^a-z])${patternLower}([^a-z]|$)`, 'i');
        return regex.test(searchString);
      }
      return false;
    });
  },

  shouldSkipField(input) {
    const skipTypes = ['hidden', 'submit', 'button', 'reset', 'image', 'file'];
    if (input.type && skipTypes.includes(input.type)) return true;

    if (input.disabled || input.readOnly) return true;

    try {
      const style = window.getComputedStyle(input);
      if (style.display === 'none') return true;
      if (style.visibility === 'hidden' && style.position !== 'absolute') return true;
    } catch (e) {}

    const rect = input.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return true;

    return false;
  },

  getSelectOptions(select) {
    return Array.from(select.options).map(option => ({
      value: option.value,
      text: option.text
    }));
  },

  getAllFields() {
    const allFields = [];
    const elements = this.findAllInputElements();
    const seen = new WeakSet();

    elements.forEach((element, index) => {
      if (seen.has(element)) return;
      seen.add(element);

      if (this.shouldSkipField(element)) return;

      const fieldType = this.detectFieldType(element);
      const attrs = this.getFieldAttributes(element);

      const tagName = element.tagName.toLowerCase();
      const isContentEditable = element.contentEditable === 'true' || element.getAttribute('contenteditable') === 'true';

      allFields.push({
        index,
        element,
        tagName,
        type: element.type || (isContentEditable ? 'contenteditable' : 'text'),
        detectedType: fieldType,
        id: element.id,
        name: element.name || element.getAttribute('name'),
        label: attrs.label,
        required: element.required || element.getAttribute('aria-required') === 'true',
        options: tagName === 'select' ? this.getSelectOptions(element) : null,
        isContentEditable
      });
    });

    return allFields;
  },

  findAllInputElements() {
    const elements = [];
    const selector = 'input, select, textarea, [contenteditable="true"], [role="textbox"], [role="combobox"]';

    elements.push(...document.querySelectorAll(selector));

    this.traverseShadowDOM(document.body, elements, selector);

    try {
      const iframes = document.querySelectorAll('iframe');
      iframes.forEach(iframe => {
        try {
          const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
          if (iframeDoc) {
            elements.push(...iframeDoc.querySelectorAll(selector));
            this.traverseShadowDOM(iframeDoc.body, elements, selector);
          }
        } catch (e) {}
      });
    } catch (e) {}

    return elements;
  },

  traverseShadowDOM(root, elements, selector = 'input, select, textarea') {
    if (!root) return;

    const allElements = root.querySelectorAll('*');
    allElements.forEach(el => {
      if (el.shadowRoot) {
        elements.push(...el.shadowRoot.querySelectorAll(selector));
        this.traverseShadowDOM(el.shadowRoot, elements, selector);
      }
    });
  }
};

const FormFiller = {
  getValueForField(fieldType, profile) {
    const valueMap = {
      email: profile.email,
      password: profile.password,
      confirmPassword: profile.password,
      firstName: profile.firstName,
      lastName: profile.lastName,
      fullName: profile.fullName,
      phone: profile.phone,
      address: profile.address.street,
      address2: '',
      city: profile.address.city,
      state: profile.address.state,
      stateAbbr: profile.address.stateAbbr,
      zipCode: profile.address.zipCode,
      country: profile.address.country,
      username: profile.username,
      company: profile.company,
      jobTitle: profile.jobTitle,
      website: profile.website,
      birthDate: profile.birthDate,
      age: String(profile.age),
      gender: profile.gender,
      subject: FakeDataGenerator.subject(),
      creditCard: FakeDataGenerator.creditCard(),
      cvv: FakeDataGenerator.cvv(),
      expirationDate: FakeDataGenerator.expirationDate(),
      expirationMonth: String(FakeDataGenerator.randomInt(1, 12)).padStart(2, '0'),
      expirationYear: String(FakeDataGenerator.randomInt(25, 30)),
      ssn: FakeDataGenerator.ssn(),
      message: FakeDataGenerator.paragraph(),
      text: FakeDataGenerator.sentence()
    };
    return valueMap[fieldType] || '';
  },

  triggerReactChange(element, value) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      'value'
    )?.set;
    const nativeTextAreaValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype,
      'value'
    )?.set;

    const setter = element.tagName === 'TEXTAREA' ? nativeTextAreaValueSetter : nativeInputValueSetter;

    if (setter) {
      setter.call(element, value);
    } else {
      element.value = value;
    }

    element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    element.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
  },

  setFieldValue(element, value) {
    element.focus();
    element.dispatchEvent(new FocusEvent('focus', { bubbles: true }));

    const isContentEditable = element.contentEditable === 'true' || element.getAttribute('contenteditable') === 'true';

    if (isContentEditable) {
      element.textContent = value;
      element.dispatchEvent(new InputEvent('input', { bubbles: true, data: value }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      this.triggerReactChange(element, value);
    }

    element.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
  },

  setSelectValue(selectElement, value) {
    const options = Array.from(selectElement.options);
    let matchedOption = options.find(opt =>
      opt.value.toLowerCase() === value.toLowerCase() ||
      opt.text.toLowerCase() === value.toLowerCase()
    );

    if (!matchedOption) {
      matchedOption = options.find(opt =>
        opt.value.toLowerCase().includes(value.toLowerCase()) ||
        opt.text.toLowerCase().includes(value.toLowerCase())
      );
    }

    if (!matchedOption && options.length > 1) {
      matchedOption = options[1];
    }

    if (matchedOption) {
      selectElement.value = matchedOption.value;
      this.triggerReactChange(selectElement, matchedOption.value);
    }
  },

  setCheckboxValue(checkbox, checked = true) {
    checkbox.checked = checked;
    checkbox.dispatchEvent(new Event('change', { bubbles: true }));
    checkbox.dispatchEvent(new Event('input', { bubbles: true }));
  },

  setRadioValue(radioGroup, value) {
    const radios = Array.from(radioGroup);
    let matchedRadio = radios.find(radio =>
      radio.value.toLowerCase() === value.toLowerCase()
    );

    if (!matchedRadio && radios.length > 0) {
      matchedRadio = radios[0];
    }

    if (matchedRadio) {
      matchedRadio.checked = true;
      matchedRadio.dispatchEvent(new Event('change', { bubbles: true }));
    }
  },

  fillField(element, fieldType, profile) {
    const tagName = element.tagName.toLowerCase();
    const inputType = element.type?.toLowerCase();

    if (tagName === 'select') {
      const value = this.getValueForField(fieldType, profile);
      this.setSelectValue(element, value);
      return { success: true, value };
    }

    if (inputType === 'checkbox') {
      this.setCheckboxValue(element, true);
      return { success: true, value: 'checked' };
    }

    if (inputType === 'radio') {
      const name = element.name;
      if (name) {
        const radioGroup = document.querySelectorAll(`input[type="radio"][name="${name}"]`);
        const value = this.getValueForField(fieldType, profile);
        this.setRadioValue(radioGroup, value);
        return { success: true, value };
      }
      return { success: false, value: null };
    }

    const value = this.getValueForField(fieldType, profile);
    this.setFieldValue(element, value);
    return { success: true, value };
  },

  fillAllForms(profile) {
    const allFields = FieldDetector.getAllFields();
    if (allFields.length === 0) {
      return { success: false, message: 'No form fields found' };
    }

    allFields.forEach((field, index) => {
      setTimeout(() => {
        this.fillField(field.element, field.detectedType, profile);
      }, index * 50);
    });

    return { success: true, fieldsCount: allFields.length };
  },

  applyTemplate(template, profile) {
    const fields = FieldDetector.getAllFields();

    template.mappings.forEach(mapping => {
      const field = fields.find(f =>
        f.id === mapping.fieldId ||
        f.name === mapping.fieldName ||
        f.detectedType === mapping.fieldType
      );

      if (field) {
        let value;
        if (mapping.customValue) {
          value = mapping.customValue;
        } else {
          value = this.getValueForField(mapping.fieldType, profile);
        }
        this.setFieldValue(field.element, value);
      }
    });
  }
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'fillAll') {
    const profile = FakeDataGenerator.generateProfile();
    const result = FormFiller.fillAllForms(profile);
    sendResponse(result);
  } else if (message.action === 'getFields') {
    const fields = FieldDetector.getAllFields().map(f => ({
      id: f.id,
      name: f.name,
      type: f.type,
      detectedType: f.detectedType,
      label: f.label,
      tagName: f.tagName
    }));
    sendResponse(fields);
  } else if (message.action === 'applyTemplate') {
    const profile = FakeDataGenerator.generateProfile();
    FormFiller.applyTemplate(message.template, profile);
    sendResponse({ success: true });
  } else if (message.action === 'fillField') {
    const profile = FakeDataGenerator.generateProfile();
    const fields = FieldDetector.getAllFields();
    const field = fields.find(f =>
      f.id === message.fieldId || f.name === message.fieldName
    );
    if (field) {
      FormFiller.fillField(field.element, message.fieldType || field.detectedType, profile);
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: 'Field not found' });
    }
  }
  return true;
});

let contextMenuField = null;

document.addEventListener('contextmenu', (e) => {
  const target = e.target;
  if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT') {
    contextMenuField = target;
    chrome.runtime.sendMessage({ action: 'showContextMenu', fieldType: FieldDetector.detectFieldType(target) });
  }
});

console.log('FormFill Pro: Content script loaded');
