class PopupController {
  constructor() {
    this.currentTab = 'fill';
    this.templates = [];
    this.detectedFields = [];
    this.editingTemplate = null;
    this.init();
  }

  async init() {
    await this.loadSettings();
    await this.loadTemplates();
    this.setupEventListeners();
    this.scanCurrentPage();
  }

  setupEventListeners() {
    document.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => this.switchTab(tab.dataset.tab));
    });

    document.getElementById('fill-all-btn').addEventListener('click', () => this.fillAllForms());
    document.getElementById('refresh-fields').addEventListener('click', () => this.scanCurrentPage());

    document.querySelectorAll('.quick-btn').forEach(btn => {
      btn.addEventListener('click', () => this.quickFill(btn.dataset.type));
    });

    document.getElementById('create-template-btn').addEventListener('click', () => this.createTemplate());
    document.getElementById('back-to-templates').addEventListener('click', () => this.closeTemplateEditor());
    document.getElementById('save-template-btn').addEventListener('click', () => this.saveTemplate());

    document.getElementById('locale-select').addEventListener('change', (e) => this.saveSetting('locale', e.target.value));
    document.getElementById('password-length').addEventListener('change', (e) => this.saveSetting('passwordLength', e.target.value));
    document.getElementById('fill-delay').addEventListener('change', (e) => this.saveSetting('fillDelay', e.target.value));
    document.getElementById('auto-submit').addEventListener('change', (e) => this.saveSetting('showAnimation', e.target.checked));
    document.getElementById('context-menu').addEventListener('change', (e) => this.saveSetting('contextMenu', e.target.checked));

    document.getElementById('export-templates').addEventListener('click', () => this.exportTemplates());
    document.getElementById('import-templates').addEventListener('click', () => document.getElementById('import-file').click());
    document.getElementById('import-file').addEventListener('change', (e) => this.importTemplates(e));
    document.getElementById('clear-data').addEventListener('click', () => this.clearAllData());
  }

  switchTab(tabName) {
    this.currentTab = tabName;

    document.querySelectorAll('.tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.tab === tabName);
    });

    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.toggle('active', content.id === `${tabName}-tab`);
    });
  }

  async scanCurrentPage() {
    const fieldsList = document.getElementById('fields-list');
    fieldsList.innerHTML = '<div class="loading">Scanning page...</div>';

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          if (typeof FieldDetector !== 'undefined') {
            return FieldDetector.getAllFields().map(f => ({
              id: f.id,
              name: f.name,
              type: f.type,
              detectedType: f.detectedType,
              label: f.label,
              tagName: f.tagName
            }));
          }
          return [];
        }
      });

      this.detectedFields = results[0]?.result || [];
      this.renderFieldsList();
    } catch (error) {
      console.error('Scan error:', error);
      fieldsList.innerHTML = '<div class="empty-fields">Unable to scan this page</div>';
    }
  }

  renderFieldsList() {
    const fieldsList = document.getElementById('fields-list');

    if (this.detectedFields.length === 0) {
      fieldsList.innerHTML = '<div class="empty-fields">No form fields detected</div>';
      return;
    }

    fieldsList.innerHTML = this.detectedFields.map((field, index) => `
      <div class="field-item" data-index="${index}">
        <div class="field-info">
          <span class="field-name">${field.label || field.name || field.id || `Field ${index + 1}`}</span>
          <span class="field-type">${field.tagName} - ${field.type}</span>
        </div>
        <span class="field-badge">${this.formatFieldType(field.detectedType)}</span>
      </div>
    `).join('');
  }

  formatFieldType(type) {
    const typeMap = {
      firstName: 'First Name',
      lastName: 'Last Name',
      fullName: 'Full Name',
      email: 'Email',
      phone: 'Phone',
      password: 'Password',
      confirmPassword: 'Confirm Pass',
      address: 'Address',
      city: 'City',
      state: 'State',
      zipCode: 'ZIP',
      country: 'Country',
      username: 'Username',
      company: 'Company',
      jobTitle: 'Job Title',
      birthDate: 'Birth Date',
      creditCard: 'Card',
      cvv: 'CVV',
      message: 'Message',
      text: 'Text'
    };
    return typeMap[type] || type;
  }

  async fillAllForms() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const profile = FakeDataGenerator.generateProfile();
          FormFiller.fillAllForms(profile);
        }
      });

      this.showToast('Forms filled successfully!');
    } catch (error) {
      console.error('Fill error:', error);
      this.showToast('Error filling forms');
    }
  }

  async quickFill(type) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        args: [type],
        func: (fillType) => {
          const profile = FakeDataGenerator.generateProfile();
          const typeMapping = {
            email: ['email'],
            phone: ['phone'],
            address: ['address', 'city', 'state', 'zipCode', 'country'],
            name: ['firstName', 'lastName', 'fullName'],
            password: ['password', 'confirmPassword'],
            card: ['creditCard', 'cvv', 'expirationDate', 'expirationMonth', 'expirationYear']
          };

          const targetTypes = typeMapping[fillType] || [];
          const fields = FieldDetector.getAllFields();

          fields.forEach(field => {
            if (targetTypes.includes(field.detectedType)) {
              FormFiller.fillField(field.element, field.detectedType, profile);
            }
          });
        }
      });

      this.showToast(`${type} fields filled!`);
    } catch (error) {
      console.error('Quick fill error:', error);
      this.showToast('Error filling fields');
    }
  }

  async loadTemplates() {
    const result = await chrome.storage.local.get('templates');
    this.templates = result.templates || [];
    this.renderTemplatesList();
  }

  renderTemplatesList() {
    const templatesList = document.getElementById('templates-list');

    if (this.templates.length === 0) {
      templatesList.innerHTML = `
        <div class="empty-state">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
            <polyline points="14 2 14 8 20 8"/>
            <line x1="12" y1="18" x2="12" y2="12"/>
            <line x1="9" y1="15" x2="15" y2="15"/>
          </svg>
          <p>No templates yet</p>
          <span>Create a template to save form configurations</span>
        </div>
      `;
      return;
    }

    templatesList.innerHTML = this.templates.map((template, index) => `
      <div class="template-item" data-index="${index}">
        <div class="template-info">
          <span class="template-name">${template.name}</span>
          <span class="template-meta">${template.mappings.length} fields</span>
        </div>
        <div class="template-actions">
          <button class="btn-icon apply-template" data-index="${index}" title="Apply">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          </button>
          <button class="btn-icon edit-template" data-index="${index}" title="Edit">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </button>
          <button class="btn-icon delete-template" data-index="${index}" title="Delete">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"/>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            </svg>
          </button>
        </div>
      </div>
    `).join('');

    templatesList.querySelectorAll('.apply-template').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.applyTemplate(parseInt(btn.dataset.index));
      });
    });

    templatesList.querySelectorAll('.edit-template').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.editTemplate(parseInt(btn.dataset.index));
      });
    });

    templatesList.querySelectorAll('.delete-template').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.deleteTemplate(parseInt(btn.dataset.index));
      });
    });
  }

  createTemplate() {
    this.editingTemplate = {
      name: 'New Template',
      mappings: this.detectedFields.map(field => ({
        fieldId: field.id,
        fieldName: field.name,
        fieldType: field.detectedType,
        customValue: ''
      }))
    };
    this.openTemplateEditor();
  }

  editTemplate(index) {
    this.editingTemplate = { ...this.templates[index], index };
    this.openTemplateEditor();
  }

  openTemplateEditor() {
    document.getElementById('templates-list').classList.add('hidden');
    document.querySelector('.templates-header').classList.add('hidden');
    document.getElementById('template-editor').classList.remove('hidden');

    document.getElementById('template-name').value = this.editingTemplate.name;
    this.renderTemplateFields();
  }

  closeTemplateEditor() {
    document.getElementById('templates-list').classList.remove('hidden');
    document.querySelector('.templates-header').classList.remove('hidden');
    document.getElementById('template-editor').classList.add('hidden');
    this.editingTemplate = null;
  }

  renderTemplateFields() {
    const container = document.getElementById('template-fields');
    const fieldTypes = [
      'firstName', 'lastName', 'fullName', 'email', 'phone', 'username',
      'password', 'address', 'city', 'state', 'zipCode', 'country',
      'company', 'jobTitle', 'birthDate', 'creditCard', 'cvv', 'message', 'text'
    ];

    container.innerHTML = this.editingTemplate.mappings.map((mapping, index) => `
      <div class="template-field-item" data-index="${index}">
        <span style="min-width: 100px; font-size: 12px; color: var(--text-secondary);">
          ${mapping.fieldName || mapping.fieldId || `Field ${index + 1}`}
        </span>
        <select class="field-type-select" data-index="${index}">
          ${fieldTypes.map(type => `
            <option value="${type}" ${mapping.fieldType === type ? 'selected' : ''}>
              ${this.formatFieldType(type)}
            </option>
          `).join('')}
        </select>
        <input type="text" class="custom-value" data-index="${index}"
               placeholder="Custom value (optional)" value="${mapping.customValue || ''}">
      </div>
    `).join('');

    container.querySelectorAll('.field-type-select').forEach(select => {
      select.addEventListener('change', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this.editingTemplate.mappings[idx].fieldType = e.target.value;
      });
    });

    container.querySelectorAll('.custom-value').forEach(input => {
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this.editingTemplate.mappings[idx].customValue = e.target.value;
      });
    });
  }

  async saveTemplate() {
    const name = document.getElementById('template-name').value.trim();
    if (!name) {
      this.showToast('Please enter a template name');
      return;
    }

    this.editingTemplate.name = name;

    if (typeof this.editingTemplate.index === 'number') {
      this.templates[this.editingTemplate.index] = {
        name: this.editingTemplate.name,
        mappings: this.editingTemplate.mappings
      };
    } else {
      this.templates.push({
        name: this.editingTemplate.name,
        mappings: this.editingTemplate.mappings
      });
    }

    await chrome.storage.local.set({ templates: this.templates });
    this.renderTemplatesList();
    this.closeTemplateEditor();
    this.showToast('Template saved!');
  }

  async deleteTemplate(index) {
    if (confirm('Delete this template?')) {
      this.templates.splice(index, 1);
      await chrome.storage.local.set({ templates: this.templates });
      this.renderTemplatesList();
      this.showToast('Template deleted');
    }
  }

  async applyTemplate(index) {
    const template = this.templates[index];

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        args: [template],
        func: (tmpl) => {
          const profile = FakeDataGenerator.generateProfile();
          FormFiller.applyTemplate(tmpl, profile);
        }
      });

      this.showToast('Template applied!');
    } catch (error) {
      console.error('Apply template error:', error);
      this.showToast('Error applying template');
    }
  }

  async loadSettings() {
    const result = await chrome.storage.local.get('settings');
    const settings = result.settings || {
      locale: 'en-US',
      passwordLength: 12,
      fillDelay: 50,
      showAnimation: false,
      contextMenu: true
    };

    document.getElementById('locale-select').value = settings.locale;
    document.getElementById('password-length').value = settings.passwordLength;
    document.getElementById('fill-delay').value = settings.fillDelay;
    document.getElementById('auto-submit').checked = settings.showAnimation;
    document.getElementById('context-menu').checked = settings.contextMenu;
  }

  async saveSetting(key, value) {
    const result = await chrome.storage.local.get('settings');
    const settings = result.settings || {};
    settings[key] = value;
    await chrome.storage.local.set({ settings });
  }

  exportTemplates() {
    const data = JSON.stringify(this.templates, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'formfill-templates.json';
    a.click();
    URL.revokeObjectURL(url);
    this.showToast('Templates exported!');
  }

  async importTemplates(event) {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const text = await file.text();
      const imported = JSON.parse(text);

      if (Array.isArray(imported)) {
        this.templates = [...this.templates, ...imported];
        await chrome.storage.local.set({ templates: this.templates });
        this.renderTemplatesList();
        this.showToast(`Imported ${imported.length} templates`);
      }
    } catch (error) {
      this.showToast('Invalid template file');
    }

    event.target.value = '';
  }

  async clearAllData() {
    if (confirm('This will delete all templates and settings. Continue?')) {
      await chrome.storage.local.clear();
      this.templates = [];
      this.renderTemplatesList();
      await this.loadSettings();
      this.showToast('All data cleared');
    }
  }

  showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = toast.querySelector('.toast-message');
    toastMessage.textContent = message;
    toast.classList.remove('hidden');

    setTimeout(() => {
      toast.classList.add('hidden');
    }, 2500);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new PopupController();
});
